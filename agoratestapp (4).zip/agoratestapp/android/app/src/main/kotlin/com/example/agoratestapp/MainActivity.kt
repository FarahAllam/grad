package com.example.agoratestapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
