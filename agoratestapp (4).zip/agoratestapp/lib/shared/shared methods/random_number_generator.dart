import 'dart:math';

int randomNumber() {
  Random random = Random();
  return random.nextInt(999999);
}
