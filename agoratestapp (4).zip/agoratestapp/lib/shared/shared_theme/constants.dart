import 'package:flutter/material.dart';

const primaryColor=Color(0xff2B475E);
const secondryColor=Colors.white;